[app]
source.dir = .
version = 1.0
# Название вашего приложения
title = Fruit Ninja
package.name = mygame
package.domain = org.test

# Укажите главный файл
source.include_exts = main.py

# Зависимости
requirements = python3,pygame

# Версия Android (минимум)
android.api = 7
